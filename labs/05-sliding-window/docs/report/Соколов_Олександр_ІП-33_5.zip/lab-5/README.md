# ЛР 5. Алгоритми ковзного вікна для обробки Time Series

Соколов Олександр, ІП-33. Рівень складності ІІ, групи вимог 1 і 2.

Залежностями керує [uv](https://docs.astral.sh/uv/). Запуск:

```sh
cd project
uv run python src/main.py                 # верифікація і обидва ряди, близько 2,5 хв
uv run python src/main.py --part verify   # лише верифікація алгоритмів
```

Програма друкує результати всіх етапів і зберігає графіки в `project/out/`.
Температура Києва (Open-Meteo) уже лежить у `project/data/`; якщо файл видалити,
програма завантажить його з API заново.

## Структура

```
project/src/main.py        точка входу: верифікація, два ряди, зведені графіки
project/src/loaders.py     завантаження: курс Ощадбанку, температура Києва з кешем
project/src/properties.py  властивості ряду: стаціонарність, ACF, PACF
project/src/smoothing.py   алгоритми ковзного вікна: SMA, WMA, медіана, EMA, ковзний МНК, сезонне MA
project/src/arima.py       ARIMA, регресія на гармоніки з ARMA-похибкою, підбір порядку
project/src/learning.py    статистичне навчання: МНК-поліном, МНК з гармоніками, α-β фільтр
project/src/evaluation.py  метрики, walk-forward перевірка, крос-валідація параметрів
project/src/study.py       етапи дослідження одного ряду
project/src/figures.py     зведені графіки
project/src/plots.py       палітра і спільні елементи графіків
project/src/verify.py      верифікація алгоритмів на рядах з відомими властивостями
docs/samples/Lab_work_5/ARMA_ARIMA/data/  курс USD за даними Ощадбанку
```
