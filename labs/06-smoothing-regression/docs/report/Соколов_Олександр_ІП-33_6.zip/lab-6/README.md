# ЛР 6. Регресійні моделі для обробки Time Series

Соколов Олександр, ІП-33. Рівень складності ІІ, групи вимог 1, 2 і 3.

Залежностями керує [uv](https://docs.astral.sh/uv/). Запуск:

```sh
cd project
uv run python src/main.py                 # верифікація, набір рядів селектора і чотири ряди, близько 5 хв
uv run python src/main.py --part verify   # лише верифікація алгоритмів
```

Програма друкує результати всіх етапів і зберігає графіки в `project/out/`.
Набір із 450 синтетичних рядів для алгоритму вибору рахується найдовше, тому
кешується в `project/out/benchmark.csv`; `--fresh` перераховує його.
Температура Києва (Open-Meteo) уже лежить у `project/data/`; якщо файл видалити,
програма завантажить його з API заново.

## Структура

```
project/src/main.py         точка входу: верифікація, селектор, чотири ряди, графіки
project/src/loaders.py      завантаження: курс Ощадбанку, температура Києва з кешем
project/src/synthetic.py    синтетичні ряди варіанта 8 з ЛР 1 і ряди для селектора
project/src/features.py     властивості ряду, детектор сезонності, ознаки для селектора
project/src/exponential.py  SES, Хольт, Хольт–Вінтерс; вибір за AIC і за CV
project/src/regression.py   поліноми, гармоніки, регресія на лаги; вибір за CV з правилом 1-SE
project/src/selector.py     алгоритм вибору сім'ї: дерево, CV, комбінація, гібрид
project/src/evaluation.py   KPI і walk-forward перевірка
project/src/study.py        етапи дослідження одного ряду
project/src/figures.py      графіки
project/src/plots.py        палітра і спільні елементи графіків
project/src/verify.py       верифікація алгоритмів на рядах з відомими властивостями
docs/samples/Lab_work_6/exponential_models/data/  курс USD за даними Ощадбанку
```
