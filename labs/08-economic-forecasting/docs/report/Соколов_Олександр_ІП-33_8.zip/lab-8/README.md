# ЛР 8. Проектний практикум з прогнозування економічних показників

Соколов Олександр, ІП-33. Рівні складності I–III: показники ефективності і динаміка
прибутку за регіонами (Pr_1.xls, варіант 8), аналіз чотирьох економічних рядів з різними
властивостями, обробка тих самих рядів трьома класами методів з інтегрованою оцінкою за
нелінійною схемою компромісів.

Залежностями керує [uv](https://docs.astral.sh/uv/). Мережі побудовані на Keras 3
з бекендом PyTorch і навчаються на CPU. Запуск:

```sh
cd project
uv run python src/main.py                  # усі рівні і верифікація, близько 2 хв
uv run python src/main.py --part level1    # лише рівень I
uv run python src/main.py --part level3    # лише рівень III
```

Програма друкує результати всіх етапів, зберігає графіки і `profit_by_region.xlsx`
у `project/out/`. Мережі навчаються паралельно в пулі процесів, результати кешуються
в `project/out/*.pkl`; `--fresh` перенавчає все. Ряди НБУ і FRED уже лежать у
`project/data/`; якщо файли видалити, програма завантажить їх з API заново.

## Структура

```
project/src/main.py          точка входу: рівні I–III, верифікація, графіки
project/src/loaders.py       Pr_1.xls з довідником регіонів, API НБУ, FRED з кешем
project/src/level1.py        показники ефективності, динаміка прибутку за регіонами, МНК
project/src/level2.py        властивості процесів, шоки, тип ряду
project/src/level3.py        сім методів трьох класів, walk-forward, інтегрований прогноз
project/src/integral.py      нелінійна схема компромісів, ентропійні ваги
project/src/learn.py         МНК-поліном з вибором степеня
project/src/detect.py        виявлення аномалій
project/src/filters.py       α-β фільтр
project/src/adaptive.py      адаптивна пам'ять фільтра, CUSUM
project/src/exponential.py   експоненційне згладжування
project/src/regression.py    регресійне згладжування
project/src/features.py      стаціонарність, сезонність, автокореляція
project/src/networks.py      MLP, LSTM, CNN
project/src/strategies.py    гібрид D(t) + мережа на залишку
project/src/runner.py        паралельне навчання з кешем
project/src/figures.py       графіки
project/src/plots.py         палітра і спільні елементи графіків
project/src/verify.py        верифікація схеми компромісів і технології
docs/samples/Lab_work_8/     Pr_1.xls – продажі мережі магазинів
```
