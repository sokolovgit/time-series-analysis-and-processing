# ЛР 4. Пошук закономірностей в структурах Time Series

Соколов Олександр, ІП-33. Рівень складності ІІІ, групи вимог 1 і 2.

Залежностями керує [uv](https://docs.astral.sh/uv/). Запуск:

```sh
cd project
uv run python src/main.py              # верифікація і обидві групи, близько 3 хв
uv run python src/main.py --group 2    # лише група 2
```

Програма друкує результати всіх етапів і зберігає графіки в `project/out/`.
Погодні дані Open-Meteo вже лежать у `project/data/`; якщо файли видалити, програма
завантажить їх з API заново.

## Структура

```
project/src/main.py           точка входу: верифікація, групи вимог 1 і 2
project/src/loaders.py        завантаження: курс Ощадбанку, API Open-Meteo з кешуванням
project/src/analysis.py       властивості: статистики, стаціонарність, Херст, STL, MSTL
project/src/patterns.py       кореляції, крос-кореляція, кластеризація
project/src/synthesis.py      моделі синтезу, генератори, перевірка адекватності
project/src/plots.py          палітра і спільні елементи графіків
project/src/study_rates.py    етапи групи 1 (курс USD)
project/src/study_weather.py  етапи групи 2 (погода 12 міст)
project/src/verify.py         верифікація методів на рядах з відомими властивостями
project/data/                 погодний архів Open-Meteo 2015–2024
docs/samples/Lab_work_4/Time_Series_Decomposition/data/  курс USD за даними Ощадбанку
```
