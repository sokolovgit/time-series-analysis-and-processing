# ЛР 9. Проектний практикум з прогнозування ієрархічних структур Time Series

Соколов Олександр, ІП-33. Рівень складності III, варіант 8: прогноз кількості
живонароджених за ієрархією Україна → область → міська/сільська місцевість
(2_dataset_POPULATION_BIRTH.xlsx) методами bottom-up, top-down (AHP, PHA, FP),
middle-out, OLS, WLS, MinT, ретроспективне порівняння методів і прогноз на 2022–2026 роки.

Залежностями керує [uv](https://docs.astral.sh/uv/). Запуск:

```sh
cd project
uv run python src/main.py      # усі етапи і верифікація, близько 10 с
```

Програма друкує результати всіх етапів, зберігає графіки і `births_forecast.xlsx`
у `project/out/`. Відібрані ряди вже лежать у `project/data/births.csv`; якщо файл
видалити, програма розбере xlsx з `docs/samples/` заново.

scikit-hts 0.5.12 під Python 3.10+ імпортується лише з підміною `collections.Iterable`,
вона виконується у `verify.py`. Бібліотека використовується для звірки BU, OLS, WLS.

## Структура

```
project/src/main.py        точка входу: етапи 1–4
project/src/loaders.py     парсинг датасету Держстату з кешем
project/src/analysis.py    попередній аналіз: повнота, узгодженість сум, злами
project/src/hierarchy.py   вузли, рівні, сумувальна матриця S
project/src/base.py        базові ETS-прогнози з вибором за AICc
project/src/reconcile.py   BU, TD-AHP, TD-PHA, TD-FP, MO, OLS, WLS, MinT
project/src/evaluate.py    ретроспективна перевірка, підсумковий прогноз
project/src/verify.py      незміщеність, когерентність, звірка зі scikit-hts
project/src/figures.py     графіки і таблиця xlsx
project/src/plots.py       палітра і спільні елементи графіків
```
